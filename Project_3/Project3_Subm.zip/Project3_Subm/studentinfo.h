#ifndef STUDENT1NFO_H
#define STUDENT1NFO_H
#include<string>

namespace StudentInfo {
	std::string name() { return "Rohit Sunil Adsue"; } //Add your name, no special characters.
	std::string id() { return "1900140"; } //Add your id, no special characters.
};

#endif
