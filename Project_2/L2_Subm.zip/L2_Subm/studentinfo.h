#ifndef STUDENTINFO_H
#define STUDENTINFO_H
#include<string>

//Insert your name is student id, letters and numbers only".
namespace StudentInfo {
	std::string name() { return "My name is Rohit Sunil Adsule"; }
	std::string id() { return "My Student ID is 1900140"; }
};

#endif