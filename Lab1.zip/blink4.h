#ifndef BLINK4_H
#define BLINK4_H

#include "constants.h"
#include "life.h"

class Blink4 : public Life {
public:
	Blink4(int r, int c);
	
	~Blink4();
};

#endif //BLINK4_H